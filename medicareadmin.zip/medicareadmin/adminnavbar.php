<div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                        <li class="active">
                            <a href="admin.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="blogs.php"><i class="fa fa-fw fa-dashboard"></i> Blogs</a>
                        </li>
                        <li>
                            <a href="Contactus.php"><i class="fa fa-fw fa-dashboard"></i> Contact Us</a>
                        </li>
                         <li>
                            <a href="walkin.php"><i class="fa fa-fw fa-dashboard"></i> Walkin Appointments</a>
                        </li>
                         <li>
                            <a href="online.php"><i class="fa fa-fw fa-dashboard"></i>Online Appointments</a>
                        </li>
                         <li>
                            <a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Home Visits</a>
                        </li>
                       
                    </ul>
                </div>
                <script src="pt/assets/js/bootstrap.min.js"></script>
        <script src="asset/js/bootstrap-clockpicker.js"></script>

                <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>