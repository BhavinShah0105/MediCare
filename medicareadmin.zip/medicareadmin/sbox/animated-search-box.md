Animated Search Box
-------------------
demo: https://bl.ocks.org/schuchard/c534dc185181f7e020bd36270b818946

A [Pen](https://codepen.io/alexpopovich/pen/PWLRgV) by [Alex](https://codepen.io/alexpopovich) on [CodePen](https://codepen.io).

[License](https://codepen.io/alexpopovich/pen/PWLRgV/license).